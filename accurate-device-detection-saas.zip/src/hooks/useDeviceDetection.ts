import { useState, useEffect } from 'react';

export interface DeviceInfo {
  // Core Identity
  deviceType: string;
  deviceModel: string;
  brand: string;
  // OS
  os: string;
  osVersion: string;
  // Browser
  browser: string;
  browserVersion: string;
  browserEngine: string;
  // Hardware
  screenWidth: number;
  screenHeight: number;
  viewportWidth: number;
  viewportHeight: number;
  pixelRatio: number;
  colorDepth: number;
  gpuVendor: string;
  gpuRenderer: string;
  cpuCores: number;
  deviceMemory: number | null;
  maxTouchPoints: number;
  // Network
  connectionType: string;
  downlink: number | null;
  // Context
  language: string;
  timezone: string;
  orientation: string;
  platform: string;
  userAgent: string;
  // Client Hints
  clientHintsModel: string | null;
  clientHintsPlatform: string | null;
  clientHintsPlatformVersion: string | null;
  clientHintsMobile: boolean | null;
  clientHintsArchitecture: string | null;
  clientHintsBitness: string | null;
  // Confidence
  confidenceScore: number;
  detectionMethod: string;
  detectionTimeMs: number;
  // Accessory Match
  accessoryCategory: string;
  compatibilityTags: string[];
}

function getGPUInfo(): { vendor: string; renderer: string } {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    if (gl && gl instanceof WebGLRenderingContext) {
      const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
      if (debugInfo) {
        return {
          vendor: gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) || 'Unknown',
          renderer: gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || 'Unknown',
        };
      }
    }
  } catch {
    // ignore
  }
  return { vendor: 'Unknown', renderer: 'Unknown' };
}

function detectOS(ua: string): { os: string; osVersion: string } {
  if (/Windows/.test(ua)) {
    const match = ua.match(/Windows NT (\d+\.\d+)/);
    const ntVersionMap: Record<string, string> = {
      '10.0': '10/11', '6.3': '8.1', '6.2': '8', '6.1': '7', '6.0': 'Vista', '5.1': 'XP',
    };
    const ntVer = match?.[1] || '';
    return { os: 'Windows', osVersion: ntVersionMap[ntVer] || ntVer };
  }
  if (/iPhone|iPad|iPod/.test(ua)) {
    const match = ua.match(/OS (\d+[_\.]\d+[_\.]?\d*)/);
    return { os: 'iOS', osVersion: match?.[1]?.replace(/_/g, '.') || 'Unknown' };
  }
  if (/Mac OS X/.test(ua)) {
    const match = ua.match(/Mac OS X (\d+[_\.]\d+[_\.]?\d*)/);
    return { os: 'macOS', osVersion: match?.[1]?.replace(/_/g, '.') || 'Unknown' };
  }
  if (/Android/.test(ua)) {
    const match = ua.match(/Android (\d+\.?\d*\.?\d*)/);
    return { os: 'Android', osVersion: match?.[1] || 'Unknown' };
  }
  if (/CrOS/.test(ua)) return { os: 'Chrome OS', osVersion: 'Unknown' };
  if (/Linux/.test(ua)) return { os: 'Linux', osVersion: 'Unknown' };
  return { os: 'Unknown', osVersion: 'Unknown' };
}

function detectBrowser(ua: string): { browser: string; browserVersion: string; engine: string } {
  // Order matters — most specific first
  if (/Edg\//.test(ua)) {
    const match = ua.match(/Edg\/(\d+[\.\d]*)/);
    return { browser: 'Microsoft Edge', browserVersion: match?.[1] || '', engine: 'Blink' };
  }
  if (/OPR\//.test(ua) || /Opera/.test(ua)) {
    const match = ua.match(/OPR\/(\d+[\.\d]*)/) || ua.match(/Opera\/(\d+[\.\d]*)/);
    return { browser: 'Opera', browserVersion: match?.[1] || '', engine: 'Blink' };
  }
  if (/Brave/.test(ua)) {
    return { browser: 'Brave', browserVersion: '', engine: 'Blink' };
  }
  if (/SamsungBrowser/.test(ua)) {
    const match = ua.match(/SamsungBrowser\/(\d+[\.\d]*)/);
    return { browser: 'Samsung Internet', browserVersion: match?.[1] || '', engine: 'Blink' };
  }
  if (/Firefox\//.test(ua)) {
    const match = ua.match(/Firefox\/(\d+[\.\d]*)/);
    return { browser: 'Firefox', browserVersion: match?.[1] || '', engine: 'Gecko' };
  }
  if (/Safari\//.test(ua) && !/Chrome\//.test(ua)) {
    const match = ua.match(/Version\/(\d+[\.\d]*)/);
    return { browser: 'Safari', browserVersion: match?.[1] || '', engine: 'WebKit' };
  }
  if (/Chrome\//.test(ua)) {
    const match = ua.match(/Chrome\/(\d+[\.\d]*)/);
    return { browser: 'Google Chrome', browserVersion: match?.[1] || '', engine: 'Blink' };
  }
  return { browser: 'Unknown', browserVersion: '', engine: 'Unknown' };
}

function detectDeviceModel(ua: string, gpu: string, screen: { w: number; h: number }, dpr: number): { model: string; brand: string; category: string } {
  // iPhone detection via screen metrics + GPU
  if (/iPhone/.test(ua)) {
    const w = Math.min(screen.w, screen.h) * dpr;
    const h = Math.max(screen.w, screen.h) * dpr;

    // iPhone model fingerprints (logical points × dpr)
    if (h >= 2796 || h >= 2778) {
      if (w >= 1290) return { model: 'iPhone 15 Pro Max / 16 Plus / 16 Pro Max', brand: 'Apple', category: 'phone-large' };
      if (w >= 1179) return { model: 'iPhone 14 Pro / 15 Pro / 16 Pro', brand: 'Apple', category: 'phone-large' };
      return { model: 'iPhone 13 Pro Max / 14 Plus / 15 Plus', brand: 'Apple', category: 'phone-large' };
    }
    if (h >= 2556 || h >= 2532) {
      return { model: 'iPhone 13 / 13 Pro / 14 / 15', brand: 'Apple', category: 'phone-standard' };
    }
    if (h >= 2340) {
      if (w >= 1080) return { model: 'iPhone 12 / 12 Pro', brand: 'Apple', category: 'phone-standard' };
      return { model: 'iPhone 12 Mini / 13 Mini', brand: 'Apple', category: 'phone-compact' };
    }
    if (h >= 1792) return { model: 'iPhone XR / 11', brand: 'Apple', category: 'phone-standard' };
    if (h >= 2436) return { model: 'iPhone X / XS / 11 Pro', brand: 'Apple', category: 'phone-standard' };
    if (h >= 1334) return { model: 'iPhone 6/7/8 / SE (2nd/3rd gen)', brand: 'Apple', category: 'phone-compact' };
    if (h >= 1136) return { model: 'iPhone 5 / 5s / SE (1st gen)', brand: 'Apple', category: 'phone-compact' };
    return { model: 'iPhone (Unknown Model)', brand: 'Apple', category: 'phone' };
  }

  // iPad detection
  if (/iPad/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1)) {
    return { model: 'iPad', brand: 'Apple', category: 'tablet' };
  }

  // Android — extract model from UA
  if (/Android/.test(ua)) {
    const match = ua.match(/;\s*([^;)]+)\s*Build\//);
    if (match) {
      const raw = match[1].trim();
      // Try to identify brand
      const brands: Record<string, string> = {
        SM: 'Samsung', Pixel: 'Google', ONEPLUS: 'OnePlus', 'ONE PLUS': 'OnePlus',
        Redmi: 'Xiaomi', Mi: 'Xiaomi', POCO: 'Xiaomi', RMX: 'Realme',
        CPH: 'OPPO', V: 'Vivo', LM: 'LG', moto: 'Motorola', Nokia: 'Nokia',
        ASUS: 'ASUS', ZTE: 'ZTE', Huawei: 'Huawei',
      };
      let brand = 'Android';
      for (const [prefix, b] of Object.entries(brands)) {
        if (raw.startsWith(prefix) || raw.toLowerCase().startsWith(prefix.toLowerCase())) {
          brand = b;
          break;
        }
      }
      const isTablet = Math.min(screen.w, screen.h) > 600;
      return { model: raw, brand, category: isTablet ? 'tablet' : 'phone' };
    }
    const isTablet = Math.min(screen.w, screen.h) > 600;
    return { model: 'Android Device', brand: 'Android', category: isTablet ? 'tablet' : 'phone' };
  }

  // Desktop detection via GPU
  if (/Windows/.test(ua)) {
    if (/NVIDIA/.test(gpu)) return { model: 'Windows PC (NVIDIA GPU)', brand: 'PC', category: 'desktop' };
    if (/AMD|Radeon/.test(gpu)) return { model: 'Windows PC (AMD GPU)', brand: 'PC', category: 'desktop' };
    if (/Intel/.test(gpu)) return { model: 'Windows PC (Intel GPU)', brand: 'PC', category: 'desktop' };
    return { model: 'Windows PC', brand: 'PC', category: 'desktop' };
  }
  if (/Mac OS X/.test(ua)) {
    if (/Apple/.test(gpu) && /M\d/.test(gpu)) return { model: 'Mac (Apple Silicon)', brand: 'Apple', category: 'desktop' };
    if (/Apple/.test(gpu)) return { model: 'Mac (Apple GPU)', brand: 'Apple', category: 'desktop' };
    return { model: 'Mac', brand: 'Apple', category: 'desktop' };
  }

  return { model: 'Unknown Device', brand: 'Unknown', category: 'unknown' };
}

function getConnectionInfo(): { type: string; downlink: number | null } {
  const nav = navigator as any;
  if (nav.connection) {
    return {
      type: nav.connection.effectiveType || nav.connection.type || 'Unknown',
      downlink: nav.connection.downlink ?? null,
    };
  }
  return { type: 'Unknown', downlink: null };
}

function getDeviceType(ua: string, touchPoints: number, screenW: number): string {
  if (/Mobi|Android.*Mobile|iPhone/.test(ua)) return 'Mobile Phone';
  if (/iPad|Android(?!.*Mobile)|Tablet/.test(ua)) return 'Tablet';
  if (touchPoints > 1 && /Macintosh/.test(ua)) return 'Tablet'; // iPad pretending to be Mac
  if (touchPoints > 0 && screenW < 800) return 'Mobile Phone';
  return 'Desktop / Laptop';
}

function getAccessoryInfo(category: string, brand: string, model: string): { accessoryCategory: string; compatibilityTags: string[] } {
  const tags: string[] = [];

  if (category.includes('phone')) {
    tags.push('Phone Case', 'Screen Protector', 'Charger', 'Cable');
    if (brand === 'Apple') {
      tags.push('Lightning / USB-C', 'MagSafe', 'AirPods');
      if (model.includes('15') || model.includes('16')) tags.push('USB-C', 'MagSafe Compatible');
      else tags.push('Lightning');
    } else {
      tags.push('USB-C', 'Wireless Charging');
    }
    return { accessoryCategory: `${brand} Phone Accessories`, compatibilityTags: tags };
  }
  if (category === 'tablet') {
    tags.push('Tablet Case', 'Screen Protector', 'Stylus', 'Keyboard');
    if (brand === 'Apple') tags.push('Apple Pencil', 'Smart Keyboard');
    return { accessoryCategory: `${brand} Tablet Accessories`, compatibilityTags: tags };
  }
  tags.push('Laptop Sleeve', 'Mouse', 'Keyboard', 'Monitor');
  return { accessoryCategory: 'Computer Accessories', compatibilityTags: tags };
}

async function getClientHints(): Promise<{
  model: string | null;
  platform: string | null;
  platformVersion: string | null;
  mobile: boolean | null;
  architecture: string | null;
  bitness: string | null;
}> {
  const result = { model: null as string | null, platform: null as string | null, platformVersion: null as string | null, mobile: null as boolean | null, architecture: null as string | null, bitness: null as string | null };
  try {
    const nav = navigator as any;
    if (nav.userAgentData) {
      result.mobile = nav.userAgentData.mobile ?? null;
      result.platform = nav.userAgentData.platform ?? null;
      if (nav.userAgentData.getHighEntropyValues) {
        const hints = await nav.userAgentData.getHighEntropyValues([
          'model', 'platform', 'platformVersion', 'architecture', 'bitness', 'fullVersionList'
        ]);
        result.model = hints.model || null;
        result.platform = hints.platform || result.platform;
        result.platformVersion = hints.platformVersion || null;
        result.architecture = hints.architecture || null;
        result.bitness = hints.bitness || null;
      }
    }
  } catch {
    // Client Hints not available
  }
  return result;
}

function calculateConfidence(info: Partial<DeviceInfo>): number {
  let score = 50;
  if (info.clientHintsModel) score += 30;
  if (info.gpuRenderer && info.gpuRenderer !== 'Unknown') score += 10;
  if (info.deviceModel && !info.deviceModel.includes('Unknown')) score += 5;
  if (info.os && info.os !== 'Unknown') score += 3;
  if (info.browser && info.browser !== 'Unknown') score += 2;
  return Math.min(score, 100);
}

export function useDeviceDetection() {
  const [deviceInfo, setDeviceInfo] = useState<DeviceInfo | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const startTime = performance.now();

    async function detect() {
      const ua = navigator.userAgent;
      const gpu = getGPUInfo();
      const { os, osVersion } = detectOS(ua);
      const { browser, browserVersion, engine } = detectBrowser(ua);
      const screenW = window.screen.width;
      const screenH = window.screen.height;
      const dpr = window.devicePixelRatio || 1;
      const { model, brand, category } = detectDeviceModel(ua, gpu.renderer, { w: screenW, h: screenH }, dpr);
      const conn = getConnectionInfo();
      const touchPoints = navigator.maxTouchPoints || 0;
      const deviceType = getDeviceType(ua, touchPoints, screenW);
      const { accessoryCategory, compatibilityTags } = getAccessoryInfo(category, brand, model);
      const hints = await getClientHints();
      const nav = navigator as any;
      const detectionTime = performance.now() - startTime;

      const info: DeviceInfo = {
        deviceType,
        deviceModel: hints.model || model,
        brand,
        os: hints.platform || os,
        osVersion: hints.platformVersion || osVersion,
        browser,
        browserVersion,
        browserEngine: engine,
        screenWidth: screenW,
        screenHeight: screenH,
        viewportWidth: window.innerWidth,
        viewportHeight: window.innerHeight,
        pixelRatio: dpr,
        colorDepth: window.screen.colorDepth,
        gpuVendor: gpu.vendor,
        gpuRenderer: gpu.renderer,
        cpuCores: navigator.hardwareConcurrency || 0,
        deviceMemory: nav.deviceMemory ?? null,
        maxTouchPoints: touchPoints,
        connectionType: conn.type,
        downlink: conn.downlink,
        language: navigator.language,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        orientation: window.screen.orientation?.type || 'unknown',
        platform: navigator.platform,
        userAgent: ua,
        clientHintsModel: hints.model,
        clientHintsPlatform: hints.platform,
        clientHintsPlatformVersion: hints.platformVersion,
        clientHintsMobile: hints.mobile,
        clientHintsArchitecture: hints.architecture,
        clientHintsBitness: hints.bitness,
        confidenceScore: 0,
        detectionMethod: hints.model ? 'Client Hints + UA + GPU Fingerprint' : 'UA Parsing + GPU Fingerprint + Screen Metrics',
        detectionTimeMs: Math.round(detectionTime * 100) / 100,
        accessoryCategory,
        compatibilityTags,
      };

      info.confidenceScore = calculateConfidence(info);
      setDeviceInfo(info);
      setLoading(false);
    }

    detect();
  }, []);

  return { deviceInfo, loading };
}

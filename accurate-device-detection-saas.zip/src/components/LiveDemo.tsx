import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Smartphone, Monitor, Tablet, Cpu, Wifi, Globe, Eye, Layers,
  ChevronDown, ChevronUp, Fingerprint, Clock, ShieldCheck, Tag
} from 'lucide-react';
import type { DeviceInfo } from '../hooks/useDeviceDetection';

function DeviceIcon({ type }: { type: string }) {
  if (type.includes('Mobile') || type.includes('Phone')) return <Smartphone className="w-8 h-8" />;
  if (type.includes('Tablet')) return <Tablet className="w-8 h-8" />;
  return <Monitor className="w-8 h-8" />;
}

function InfoCard({ icon: Icon, label, value, color = 'cyan' }: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string | number | null;
  color?: string;
}) {
  const colorClasses: Record<string, string> = {
    cyan: 'from-cyan-500/20 to-cyan-500/5 border-cyan-500/20 text-cyan-400',
    blue: 'from-blue-500/20 to-blue-500/5 border-blue-500/20 text-blue-400',
    purple: 'from-purple-500/20 to-purple-500/5 border-purple-500/20 text-purple-400',
    green: 'from-emerald-500/20 to-emerald-500/5 border-emerald-500/20 text-emerald-400',
    yellow: 'from-yellow-500/20 to-yellow-500/5 border-yellow-500/20 text-yellow-400',
    pink: 'from-pink-500/20 to-pink-500/5 border-pink-500/20 text-pink-400',
  };

  return (
    <div className={`rounded-xl border bg-gradient-to-br p-4 ${colorClasses[color]}`}>
      <div className="flex items-center gap-2 mb-2">
        <Icon className="w-4 h-4 opacity-70" />
        <span className="text-xs font-medium uppercase tracking-wider opacity-70">{label}</span>
      </div>
      <p className="text-sm font-semibold text-white truncate">{value ?? 'N/A'}</p>
    </div>
  );
}

export function LiveDemo({ deviceInfo, loading }: { deviceInfo: DeviceInfo | null; loading: boolean }) {
  const [expanded, setExpanded] = useState(false);

  if (loading) {
    return (
      <section id="demo" className="py-24 bg-gray-950">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center">
            <motion.div
              className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-cyan-500/10 mb-6"
              animate={{ scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Fingerprint className="w-10 h-10 text-cyan-400" />
            </motion.div>
            <h2 className="text-3xl font-bold text-white mb-4">Scanning Your Device...</h2>
            <div className="flex justify-center gap-1">
              {[0, 1, 2].map(i => (
                <motion.div
                  key={i}
                  className="w-2 h-2 rounded-full bg-cyan-400"
                  animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
                />
              ))}
            </div>
          </div>
        </div>
      </section>
    );
  }

  if (!deviceInfo) return null;
  const d = deviceInfo;

  return (
    <section id="demo" className="py-24 bg-gray-950 relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(6,182,212,0.08),transparent_60%)]" />

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-medium mb-4"
          >
            <Eye className="w-3 h-3" /> LIVE DETECTION RESULT
          </motion.div>
          <h2 className="text-3xl sm:text-5xl font-black text-white mb-4">
            We Already Know <span className="text-cyan-400">Your Device</span>
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto">
            The moment you loaded this page, our detection engine identified your device. 
            Here's everything we know — in real time.
          </p>
        </div>

        {/* Main detection card */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative rounded-2xl bg-gradient-to-br from-gray-900 to-gray-950 border border-white/10 overflow-hidden shadow-2xl shadow-cyan-500/5"
        >
          {/* Top banner */}
          <div className="bg-gradient-to-r from-cyan-500/10 via-blue-500/10 to-purple-500/10 border-b border-white/5 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/30">
                <DeviceIcon type={d.deviceType} />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">{d.deviceModel}</h3>
                <p className="text-sm text-gray-400">{d.brand} · {d.deviceType}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <div>
                  <span className="text-2xl font-black text-emerald-400">{d.confidenceScore}%</span>
                  <p className="text-[10px] text-gray-500 uppercase tracking-wider">Confidence</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-yellow-400" />
                <div>
                  <span className="text-2xl font-black text-yellow-400">{d.detectionTimeMs}ms</span>
                  <p className="text-[10px] text-gray-500 uppercase tracking-wider">Detection Time</p>
                </div>
              </div>
            </div>
          </div>

          {/* Info grid */}
          <div className="p-6">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              <InfoCard icon={Layers} label="OS" value={`${d.os} ${d.osVersion}`} color="blue" />
              <InfoCard icon={Globe} label="Browser" value={`${d.browser} ${d.browserVersion.split('.')[0]}`} color="purple" />
              <InfoCard icon={Monitor} label="Screen" value={`${d.screenWidth}×${d.screenHeight} @${d.pixelRatio}x`} color="cyan" />
              <InfoCard icon={Cpu} label="CPU Cores" value={d.cpuCores} color="green" />
              <InfoCard icon={Cpu} label="GPU" value={d.gpuRenderer.slice(0, 40)} color="pink" />
              <InfoCard icon={Wifi} label="Connection" value={d.connectionType} color="yellow" />
              <InfoCard icon={Globe} label="Language" value={d.language} color="blue" />
              <InfoCard icon={Clock} label="Timezone" value={d.timezone} color="purple" />
            </div>

            {/* Accessory matching */}
            <div className="mt-6 p-4 rounded-xl bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border border-emerald-500/20">
              <div className="flex items-center gap-2 mb-3">
                <Tag className="w-4 h-4 text-emerald-400" />
                <span className="text-sm font-semibold text-emerald-400">ACCESSORY COMPATIBILITY MATCH</span>
              </div>
              <p className="text-white font-medium mb-2">{d.accessoryCategory}</p>
              <div className="flex flex-wrap gap-2">
                {d.compatibilityTags.map((tag, i) => (
                  <span
                    key={i}
                    className="px-3 py-1 text-xs font-medium rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/20"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Detection method */}
            <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-gray-500">
              <Fingerprint className="w-3 h-3" />
              <span>Detection Method: <span className="text-gray-400">{d.detectionMethod}</span></span>
            </div>
          </div>

          {/* Expanded raw data */}
          <div className="border-t border-white/5">
            <button
              onClick={() => setExpanded(!expanded)}
              className="w-full px-6 py-3 flex items-center justify-center gap-2 text-sm text-gray-400 hover:text-white transition-colors"
            >
              {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              {expanded ? 'Hide' : 'Show'} Raw Detection Data
            </button>

            <AnimatePresence>
              {expanded && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <div className="px-6 pb-6">
                    <div className="rounded-xl bg-gray-900/80 border border-white/5 p-4 font-mono text-xs text-gray-400 overflow-x-auto max-h-[400px] overflow-y-auto">
                      <pre className="whitespace-pre-wrap">{JSON.stringify(d, null, 2)}</pre>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>

        {/* Simulated Shop Demo */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16"
        >
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-white mb-2">Simulated Shop Experience</h3>
            <p className="text-gray-400 text-sm">Here's what a webshop would look like when filtered for <span className="text-cyan-400 font-medium">{d.deviceModel}</span></p>
          </div>

          <div className="rounded-2xl bg-gray-900 border border-white/10 overflow-hidden">
            {/* Mock browser bar */}
            <div className="bg-gray-800/50 border-b border-white/5 px-4 py-2.5 flex items-center gap-3">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500/60" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
                <div className="w-3 h-3 rounded-full bg-green-500/60" />
              </div>
              <div className="flex-1 flex justify-center">
                <div className="px-4 py-1 rounded-lg bg-gray-700/50 text-xs text-gray-400 flex items-center gap-2 max-w-xs w-full">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  accessories-shop.com/{d.brand.toLowerCase()}
                </div>
              </div>
            </div>

            {/* Banner */}
            <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-b border-white/5 px-6 py-3 flex items-center justify-center gap-2">
              <Fingerprint className="w-4 h-4 text-cyan-400" />
              <span className="text-sm text-cyan-300">
                🎯 Showing accessories for <strong>{d.deviceModel}</strong> — <span className="underline cursor-pointer">Not your device?</span>
              </span>
            </div>

            {/* Product grid */}
            <div className="p-6">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {[
                  { name: 'Premium Case', price: '$29.99', emoji: '🛡️', tag: 'Best Seller' },
                  { name: 'Screen Protector', price: '$14.99', emoji: '📱', tag: 'Popular' },
                  { name: 'Charging Cable', price: '$19.99', emoji: '🔌', tag: 'Fast Charge' },
                  { name: 'Wireless Charger', price: '$39.99', emoji: '⚡', tag: 'MagSafe' },
                ].map((product, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className="rounded-xl bg-gray-800/50 border border-white/5 p-4 hover:border-cyan-500/30 transition-all cursor-pointer group"
                  >
                    <div className="text-4xl mb-3 text-center">{product.emoji}</div>
                    <span className="inline-block px-2 py-0.5 text-[10px] font-medium rounded-full bg-cyan-500/15 text-cyan-400 mb-2">{product.tag}</span>
                    <p className="text-sm font-medium text-white mb-1">{product.name}</p>
                    <p className="text-xs text-gray-500 mb-2">For {d.deviceModel.split('/')[0].trim()}</p>
                    <p className="text-lg font-bold text-cyan-400">{product.price}</p>
                    <button className="mt-3 w-full py-2 text-xs font-medium bg-cyan-500/10 text-cyan-400 rounded-lg border border-cyan-500/20 group-hover:bg-cyan-500 group-hover:text-white transition-all">
                      Add to Cart
                    </button>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

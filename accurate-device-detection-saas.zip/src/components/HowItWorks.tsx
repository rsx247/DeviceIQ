import { motion } from 'framer-motion';
import { Globe, Server, Database, ShoppingCart, ArrowRight } from 'lucide-react';

const steps = [
  {
    icon: Globe,
    title: 'User Visits Shop',
    description: 'A customer opens your webshop on their phone. Before any content loads, the detection begins.',
    color: 'cyan',
    detail: 'Browser sends HTTP request →',
  },
  {
    icon: Server,
    title: 'Edge Detection',
    description: 'Our SaaS layer at the network edge performs the UA-CH handshake and GPU fingerprint check in under 1ms.',
    color: 'blue',
    detail: 'Client Hints + Fingerprint →',
  },
  {
    icon: Database,
    title: 'Device Match',
    description: 'The signal is matched against our database of 50,000+ device models to find the exact make and model.',
    color: 'purple',
    detail: 'X-Device-ID injected →',
  },
  {
    icon: ShoppingCart,
    title: 'Filtered Shop',
    description: 'Your shop receives the device tag and serves a page with only compatible accessories. The user sees a perfect, personalized experience.',
    color: 'emerald',
    detail: '✅ Done. Zero input needed.',
  },
];

const colorMap: Record<string, { bg: string; icon: string; border: string; glow: string }> = {
  cyan: { bg: 'bg-cyan-500/10', icon: 'text-cyan-400', border: 'border-cyan-500/20', glow: 'shadow-cyan-500/20' },
  blue: { bg: 'bg-blue-500/10', icon: 'text-blue-400', border: 'border-blue-500/20', glow: 'shadow-blue-500/20' },
  purple: { bg: 'bg-purple-500/10', icon: 'text-purple-400', border: 'border-purple-500/20', glow: 'shadow-purple-500/20' },
  emerald: { bg: 'bg-emerald-500/10', icon: 'text-emerald-400', border: 'border-emerald-500/20', glow: 'shadow-emerald-500/20' },
};

export function HowItWorks() {
  return (
    <section id="how-it-works" className="py-24 bg-gray-950 relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,rgba(59,130,246,0.08),transparent_60%)]" />

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-medium mb-4">
            ARCHITECTURE
          </span>
          <h2 className="text-3xl sm:text-5xl font-black text-white mb-4">
            How It Works: <span className="text-blue-400">The Pre-Flight Handshake</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Detection happens at the network edge — before your server even receives the request.
            The page is born filtered.
          </p>
        </motion.div>

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
          {steps.map((step, i) => {
            const c = colorMap[step.color];
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="relative"
              >
                {i < steps.length - 1 && (
                  <div className="hidden md:flex absolute top-12 -right-3 z-10">
                    <ArrowRight className="w-6 h-6 text-gray-700" />
                  </div>
                )}
                <div className={`h-full rounded-2xl border ${c.border} ${c.bg} p-6 backdrop-blur-sm`}>
                  <div className={`w-12 h-12 rounded-xl ${c.bg} flex items-center justify-center mb-4 shadow-lg ${c.glow}`}>
                    <step.icon className={`w-6 h-6 ${c.icon}`} />
                  </div>
                  <div className="text-xs font-bold text-gray-600 mb-2">STEP {i + 1}</div>
                  <h3 className="text-lg font-bold text-white mb-2">{step.title}</h3>
                  <p className="text-sm text-gray-400 mb-4">{step.description}</p>
                  <span className={`text-xs font-mono ${c.icon} opacity-70`}>{step.detail}</span>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Code snippet */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="rounded-2xl bg-gray-900 border border-white/10 overflow-hidden"
        >
          <div className="bg-gray-800/50 border-b border-white/5 px-4 py-2.5 flex items-center gap-3">
            <div className="flex gap-1.5">
              <div className="w-3 h-3 rounded-full bg-red-500/60" />
              <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
              <div className="w-3 h-3 rounded-full bg-green-500/60" />
            </div>
            <span className="text-xs text-gray-500 font-mono">integration.js — Drop-in Script (2 lines)</span>
          </div>
          <div className="p-6 font-mono text-sm overflow-x-auto">
            <div className="text-gray-500 mb-1">{"// Add to your <head> — that's it."}</div>
            <div>
              <span className="text-purple-400">{'<'}</span>
              <span className="text-red-400">script</span>
              <span className="text-yellow-300"> src</span>
              <span className="text-white">=</span>
              <span className="text-green-400">"https://cdn.deviceiq.io/detect.js"</span>
              <span className="text-purple-400">{'>'}</span>
              <span className="text-purple-400">{'</'}</span>
              <span className="text-red-400">script</span>
              <span className="text-purple-400">{'>'}</span>
            </div>
            <div className="mt-4 text-gray-500">{"// Or server-side via edge proxy:"}</div>
            <div>
              <span className="text-cyan-400">DNS</span>
              <span className="text-white"> → </span>
              <span className="text-green-400">deviceiq-proxy.yourshop.com</span>
              <span className="text-white"> → </span>
              <span className="text-yellow-400">Auto-injects X-Device-ID header</span>
            </div>
            <div className="mt-4 text-gray-500">{"// Response header your shop receives:"}</div>
            <div>
              <span className="text-cyan-400">X-Device-ID</span>
              <span className="text-white">: </span>
              <span className="text-green-400">iPhone-15-Pro-Max</span>
            </div>
            <div>
              <span className="text-cyan-400">X-Device-Category</span>
              <span className="text-white">: </span>
              <span className="text-green-400">phone-large</span>
            </div>
            <div>
              <span className="text-cyan-400">X-Detection-Confidence</span>
              <span className="text-white">: </span>
              <span className="text-green-400">100</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

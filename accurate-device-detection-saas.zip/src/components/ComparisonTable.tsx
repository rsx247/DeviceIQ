import { motion } from 'framer-motion';
import { Check, X, Minus } from 'lucide-react';

const rows = [
  { feature: 'Detection Speed', clientSide: 'Slow (200-500ms)', serverSide: 'Instant (<1ms)', deviceIQ: 'Instant (<1ms)' },
  { feature: 'Accuracy', clientSide: '~85%', serverSide: '~95%', deviceIQ: '100%' },
  { feature: 'Page Flash / Layout Shift', clientSide: true, serverSide: false, deviceIQ: false },
  { feature: 'Works Without JavaScript', clientSide: false, serverSide: true, deviceIQ: true },
  { feature: 'iPhone Model Detection', clientSide: false, serverSide: false, deviceIQ: true },
  { feature: 'SEO Friendly', clientSide: false, serverSide: true, deviceIQ: true },
  { feature: 'Privacy Compliant', clientSide: 'Partial', serverSide: true, deviceIQ: true },
  { feature: 'Setup Complexity', clientSide: 'Low', serverSide: 'High', deviceIQ: '2 Lines' },
  { feature: 'Device Database', clientSide: 'Basic', serverSide: 'Manual', deviceIQ: '50K+ Models' },
  { feature: 'Edge Network', clientSide: false, serverSide: false, deviceIQ: true },
  { feature: 'Accessory Mapping', clientSide: false, serverSide: false, deviceIQ: true },
  { feature: 'Analytics Dashboard', clientSide: false, serverSide: false, deviceIQ: true },
];

function CellValue({ value }: { value: boolean | string }) {
  if (value === true) return <Check className="w-5 h-5 text-emerald-400 mx-auto" />;
  if (value === false) return <X className="w-5 h-5 text-red-400/50 mx-auto" />;
  if (value === 'Partial') return <Minus className="w-5 h-5 text-yellow-400 mx-auto" />;
  return <span className="text-sm text-gray-300">{value}</span>;
}

export function ComparisonTable() {
  return (
    <section id="comparison" className="py-24 bg-gray-950 relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(6,182,212,0.06),transparent_50%)]" />

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-medium mb-4">
            COMPARISON
          </span>
          <h2 className="text-3xl sm:text-5xl font-black text-white mb-4">
            Why DeviceIQ <span className="text-cyan-400">Wins</span>
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto">
            Client-side scripts, manual server setup, or DeviceIQ. The choice is clear.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="rounded-2xl bg-gray-900 border border-white/10 overflow-hidden overflow-x-auto"
        >
          <table className="w-full min-w-[600px]">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-400">Feature</th>
                <th className="text-center px-4 py-4 text-sm font-medium text-gray-400">
                  <div className="flex flex-col items-center">
                    <span>Client-Side JS</span>
                    <span className="text-[10px] text-gray-600">DIY / Basic</span>
                  </div>
                </th>
                <th className="text-center px-4 py-4 text-sm font-medium text-gray-400">
                  <div className="flex flex-col items-center">
                    <span>Server-Side</span>
                    <span className="text-[10px] text-gray-600">Custom Build</span>
                  </div>
                </th>
                <th className="text-center px-4 py-4">
                  <div className="flex flex-col items-center">
                    <span className="text-sm font-bold text-cyan-400">DeviceIQ</span>
                    <span className="text-[10px] text-cyan-500/70">Full SaaS</span>
                  </div>
                </th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => (
                <tr
                  key={i}
                  className={`border-b border-white/5 ${i % 2 === 0 ? 'bg-gray-900/50' : 'bg-gray-950/50'}`}
                >
                  <td className="px-6 py-3.5 text-sm text-gray-300 font-medium">{row.feature}</td>
                  <td className="px-4 py-3.5 text-center"><CellValue value={row.clientSide} /></td>
                  <td className="px-4 py-3.5 text-center"><CellValue value={row.serverSide} /></td>
                  <td className="px-4 py-3.5 text-center bg-cyan-500/[0.03]">
                    <CellValue value={row.deviceIQ} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      </div>
    </section>
  );
}

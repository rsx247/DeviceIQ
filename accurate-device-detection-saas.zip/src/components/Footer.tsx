import { Fingerprint } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-950 border-t border-white/5 py-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center">
                <Fingerprint className="w-4 h-4 text-white" />
              </div>
              <span className="text-lg font-bold text-white">
                Device<span className="text-cyan-400">IQ</span>
              </span>
            </div>
            <p className="text-sm text-gray-500 leading-relaxed">
              Invisible device detection for e-commerce. Know your customers' devices before the page loads.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-white mb-4">Product</h4>
            <ul className="space-y-2">
              {['Features', 'Pricing', 'API Docs', 'Integrations', 'Changelog'].map(item => (
                <li key={item}>
                  <a href="#" className="text-sm text-gray-500 hover:text-gray-300 transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-white mb-4">Company</h4>
            <ul className="space-y-2">
              {['About', 'Blog', 'Careers', 'Contact', 'Partners'].map(item => (
                <li key={item}>
                  <a href="#" className="text-sm text-gray-500 hover:text-gray-300 transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-white mb-4">Legal</h4>
            <ul className="space-y-2">
              {['Privacy Policy', 'Terms of Service', 'GDPR', 'CCPA', 'Security'].map(item => (
                <li key={item}>
                  <a href="#" className="text-sm text-gray-500 hover:text-gray-300 transition-colors">{item}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-white/5 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-gray-600">© 2025 DeviceIQ. All rights reserved.</p>
          <p className="text-xs text-gray-600">
            This is a demo showcase. Detection runs entirely in your browser.
          </p>
        </div>
      </div>
    </footer>
  );
}

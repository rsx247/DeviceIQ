import { useState } from 'react';
import { Fingerprint, Menu, X } from 'lucide-react';

export function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-gray-950/80 backdrop-blur-xl border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Fingerprint className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-white tracking-tight">
              Device<span className="text-cyan-400">IQ</span>
            </span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <a href="#demo" className="text-sm text-gray-400 hover:text-white transition-colors">Live Demo</a>
            <a href="#how-it-works" className="text-sm text-gray-400 hover:text-white transition-colors">How It Works</a>
            <a href="#features" className="text-sm text-gray-400 hover:text-white transition-colors">Features</a>
            <a href="#comparison" className="text-sm text-gray-400 hover:text-white transition-colors">Comparison</a>
            <a href="#pricing" className="text-sm text-gray-400 hover:text-white transition-colors">Pricing</a>
            <a
              href="#demo"
              className="px-4 py-2 text-sm font-medium bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-lg hover:from-cyan-400 hover:to-blue-500 transition-all shadow-lg shadow-cyan-500/25"
            >
              Try It Free
            </a>
          </div>

          <button onClick={() => setOpen(!open)} className="md:hidden text-gray-400">
            {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden bg-gray-950/95 backdrop-blur-xl border-t border-white/5 px-4 pb-4 space-y-2">
          <a href="#demo" onClick={() => setOpen(false)} className="block py-2 text-gray-400 hover:text-white">Live Demo</a>
          <a href="#how-it-works" onClick={() => setOpen(false)} className="block py-2 text-gray-400 hover:text-white">How It Works</a>
          <a href="#features" onClick={() => setOpen(false)} className="block py-2 text-gray-400 hover:text-white">Features</a>
          <a href="#comparison" onClick={() => setOpen(false)} className="block py-2 text-gray-400 hover:text-white">Comparison</a>
          <a href="#pricing" onClick={() => setOpen(false)} className="block py-2 text-gray-400 hover:text-white">Pricing</a>
        </div>
      )}
    </nav>
  );
}

import { motion } from 'framer-motion';
import { Check, Sparkles } from 'lucide-react';

const plans = [
  {
    name: 'Starter',
    price: '$49',
    period: '/mo',
    description: 'For small shops getting started',
    features: [
      '10,000 detections/month',
      'Client-side detection',
      'Basic device database',
      'Shopify integration',
      'Email support',
    ],
    cta: 'Start Free Trial',
    popular: false,
    color: 'gray',
  },
  {
    name: 'Professional',
    price: '$199',
    period: '/mo',
    description: 'For growing e-commerce brands',
    features: [
      '100,000 detections/month',
      'Edge + Client detection',
      'Full device database (50K+)',
      'All platform integrations',
      'Accessory mapping engine',
      'Analytics dashboard',
      'Priority support',
      'Custom branding',
    ],
    cta: 'Start Free Trial',
    popular: true,
    color: 'cyan',
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    period: '',
    description: 'For large-scale operations',
    features: [
      'Unlimited detections',
      'Dedicated edge nodes',
      'GPU fingerprint engine',
      'Custom device database',
      'White-label solution',
      'SLA guarantee (99.99%)',
      'Dedicated engineer',
      'On-premise option',
    ],
    cta: 'Contact Sales',
    popular: false,
    color: 'purple',
  },
];

export function Pricing() {
  return (
    <section id="pricing" className="py-24 bg-gray-950 relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,rgba(6,182,212,0.08),transparent_60%)]" />

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-medium mb-4">
            PRICING
          </span>
          <h2 className="text-3xl sm:text-5xl font-black text-white mb-4">
            Simple, Transparent <span className="text-emerald-400">Pricing</span>
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto">
            Start free. Scale as you grow. No hidden fees.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className={`relative rounded-2xl border p-8 flex flex-col ${
                plan.popular
                  ? 'bg-gradient-to-b from-cyan-500/10 to-gray-900 border-cyan-500/30 shadow-2xl shadow-cyan-500/10'
                  : 'bg-gray-900/50 border-white/10'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-bold shadow-lg">
                    <Sparkles className="w-3 h-3" /> MOST POPULAR
                  </span>
                </div>
              )}

              <div className="mb-6">
                <h3 className="text-lg font-bold text-white mb-1">{plan.name}</h3>
                <p className="text-sm text-gray-500">{plan.description}</p>
              </div>

              <div className="mb-6">
                <span className="text-4xl font-black text-white">{plan.price}</span>
                <span className="text-gray-500">{plan.period}</span>
              </div>

              <ul className="space-y-3 mb-8 flex-1">
                {plan.features.map((feature, j) => (
                  <li key={j} className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
                    <span className="text-sm text-gray-300">{feature}</span>
                  </li>
                ))}
              </ul>

              <button
                className={`w-full py-3 rounded-xl text-sm font-semibold transition-all ${
                  plan.popular
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:from-cyan-400 hover:to-blue-500 shadow-lg shadow-cyan-500/25'
                    : 'bg-white/5 text-white border border-white/10 hover:bg-white/10'
                }`}
              >
                {plan.cta}
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { motion } from 'framer-motion';
import {
  Fingerprint, Zap, Shield, Globe, ShoppingCart, Code,
  Smartphone, Eye, BarChart3, Lock, RefreshCw, Cpu
} from 'lucide-react';

const features = [
  {
    icon: Fingerprint,
    title: 'GPU Fingerprinting',
    description: 'Unique floating-point math patterns identify exact hardware — even when Safari hides the model name.',
    color: 'cyan',
  },
  {
    icon: Zap,
    title: 'Sub-Millisecond',
    description: 'Edge detection at CDN level means zero latency. The page arrives already personalized.',
    color: 'yellow',
  },
  {
    icon: Shield,
    title: '100% Accuracy',
    description: 'Multi-signal fusion: Client Hints + UA + GPU + Screen metrics. No guesswork.',
    color: 'emerald',
  },
  {
    icon: Eye,
    title: 'Invisible to Users',
    description: 'No popups, no dropdowns, no "select your device." It just works — silently.',
    color: 'blue',
  },
  {
    icon: ShoppingCart,
    title: 'Shop Integration',
    description: 'Shopify, WooCommerce, BigCommerce — one-click installs. Or use our REST API for custom builds.',
    color: 'purple',
  },
  {
    icon: Globe,
    title: 'Edge Network',
    description: 'Runs on 300+ edge nodes worldwide. Detection happens closest to the user.',
    color: 'pink',
  },
  {
    icon: Code,
    title: '2-Line Integration',
    description: 'Drop a script tag or point your DNS. Full detection in under 2 lines of code.',
    color: 'cyan',
  },
  {
    icon: Smartphone,
    title: '50K+ Device Database',
    description: 'Every phone, tablet, and laptop ever made. Updated weekly with new releases.',
    color: 'yellow',
  },
  {
    icon: BarChart3,
    title: 'Analytics Dashboard',
    description: 'See which devices visit your shop. Optimize inventory based on real device data.',
    color: 'emerald',
  },
  {
    icon: Lock,
    title: 'Privacy Compliant',
    description: 'GDPR & CCPA ready. No personal data stored. Hardware signals only.',
    color: 'blue',
  },
  {
    icon: RefreshCw,
    title: 'Session Persistence',
    description: 'Device selection persists through the entire session — browsing, cart, and checkout.',
    color: 'purple',
  },
  {
    icon: Cpu,
    title: 'Fallback UX',
    description: 'For desktop users or unrecognized devices: a beautiful 1-click device selector as backup.',
    color: 'pink',
  },
];

const colorMap: Record<string, { bg: string; text: string; border: string }> = {
  cyan: { bg: 'bg-cyan-500/10', text: 'text-cyan-400', border: 'group-hover:border-cyan-500/30' },
  yellow: { bg: 'bg-yellow-500/10', text: 'text-yellow-400', border: 'group-hover:border-yellow-500/30' },
  emerald: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'group-hover:border-emerald-500/30' },
  blue: { bg: 'bg-blue-500/10', text: 'text-blue-400', border: 'group-hover:border-blue-500/30' },
  purple: { bg: 'bg-purple-500/10', text: 'text-purple-400', border: 'group-hover:border-purple-500/30' },
  pink: { bg: 'bg-pink-500/10', text: 'text-pink-400', border: 'group-hover:border-pink-500/30' },
};

export function Features() {
  return (
    <section id="features" className="py-24 bg-gray-950 relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(139,92,246,0.06),transparent_60%)]" />

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-xs font-medium mb-4">
            CAPABILITIES
          </span>
          <h2 className="text-3xl sm:text-5xl font-black text-white mb-4">
            Built for <span className="text-purple-400">Production Scale</span>
          </h2>
          <p className="text-gray-400 max-w-xl mx-auto">
            Enterprise-grade detection that powers millions of accessory sales.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map((feature, i) => {
            const c = colorMap[feature.color];
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: (i % 3) * 0.1 }}
                className={`group rounded-xl bg-gray-900/50 border border-white/5 ${c.border} p-6 hover:bg-gray-900/80 transition-all cursor-default`}
              >
                <div className={`w-10 h-10 rounded-lg ${c.bg} flex items-center justify-center mb-4`}>
                  <feature.icon className={`w-5 h-5 ${c.text}`} />
                </div>
                <h3 className="text-base font-bold text-white mb-2">{feature.title}</h3>
                <p className="text-sm text-gray-400 leading-relaxed">{feature.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

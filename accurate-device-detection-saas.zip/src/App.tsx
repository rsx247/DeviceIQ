import { useDeviceDetection } from './hooks/useDeviceDetection';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { LiveDemo } from './components/LiveDemo';
import { HowItWorks } from './components/HowItWorks';
import { Features } from './components/Features';
import { ComparisonTable } from './components/ComparisonTable';
import { Pricing } from './components/Pricing';
import { Footer } from './components/Footer';

export function App() {
  const { deviceInfo, loading } = useDeviceDetection();

  return (
    <div className="bg-gray-950 text-white antialiased">
      <Navbar />
      <HeroSection deviceInfo={deviceInfo} loading={loading} />
      <LiveDemo deviceInfo={deviceInfo} loading={loading} />
      <HowItWorks />
      <Features />
      <ComparisonTable />
      <Pricing />
      <Footer />
    </div>
  );
}
